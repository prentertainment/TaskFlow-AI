import { GoogleGenAI, Type } from "@google/genai";
import { Task, Priority } from "../types";

const apiKey = process.env.GEMINI_API_KEY || "";
const genAI = new GoogleGenAI({ apiKey });

export const parseTaskFromNaturalLanguage = async (text: string) => {
  const model = "gemini-3-flash-preview";
  const response = await genAI.models.generateContent({
    model,
    contents: `Parse the following user request into a task object. 
    User request: "${text}"
    
    Return a JSON object with:
    - title: string
    - description: string
    - why: string (infer the purpose if not stated)
    - priority: "critical" | "important" | "backlog"
    - dueDate: string (ISO format if mentioned, else null)`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          why: { type: Type.STRING },
          priority: { type: Type.STRING, enum: ["critical", "important", "backlog"] },
          dueDate: { type: Type.STRING, nullable: true },
        },
        required: ["title", "description", "why", "priority"],
      },
    },
  });

  try {
    return JSON.parse(response.text);
  } catch (e) {
    console.error("Failed to parse AI response", e);
    return null;
  }
};

export const getAIAdvice = async (tasks: Task[], query: string) => {
  const model = "gemini-3-flash-preview";
  const taskSummary = tasks.map(t => `- [${t.priority}] ${t.title} (${t.completed ? 'Done' : 'Pending'})`).join('\n');
  
  const response = await genAI.models.generateContent({
    model,
    contents: `You are TaskFlow AI, a productivity coach. 
    Current Tasks:
    ${taskSummary}
    
    User Query: "${query}"
    
    Provide concise, actionable advice. Keep it under 3 sentences.`,
  });

  return response.text;
};
