export type Priority = 'critical' | 'important' | 'backlog';

export interface Task {
  id: string;
  title: string;
  description: string;
  why: string;
  priority: Priority;
  completed: boolean;
  createdAt: number;
  dueDate?: string;
  goalId?: string;
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  targetDate: string;
  progress: number;
  color: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface AnalyticsData {
  day: string;
  completed: number;
  total: number;
}
