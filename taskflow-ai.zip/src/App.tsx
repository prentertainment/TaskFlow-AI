import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Target, 
  MessageSquare, 
  BarChart3, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Trash2, 
  ChevronRight,
  Sparkles,
  Send,
  Calendar,
  AlertCircle,
  X
} from 'lucide-react';
import { cn } from './lib/utils';
import { Task, Goal, Message, Priority } from './types';
import { parseTaskFromNaturalLanguage, getAIAdvice } from './lib/gemini';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';

// --- Constants ---
const BOX_LIMITS = {
  critical: 3,
  important: 5,
  backlog: Infinity
};

const PRIORITY_COLORS = {
  critical: 'text-rose-500 bg-rose-500/10 border-rose-500/20',
  important: 'text-amber-500 bg-amber-500/10 border-amber-500/20',
  backlog: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20'
};

// --- Main App Component ---
export default function App() {
  const [activeTab, setActiveTab] = useState<'board' | 'goals' | 'chat' | 'analytics'>('board');
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('taskflow_tasks');
    return saved ? JSON.parse(saved) : [];
  });
  const [goals, setGoals] = useState<Goal[]>(() => {
    const saved = localStorage.getItem('taskflow_goals');
    return saved ? JSON.parse(saved) : [
      { id: '1', title: 'Master React', description: 'Deep dive into React 19', targetDate: '2026-05-01', progress: 65, color: '#f43f5e' },
      { id: '2', title: 'Fitness Goal', description: 'Run 20km weekly', targetDate: '2026-04-30', progress: 30, color: '#10b981' }
    ];
  });
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTask, setNewTask] = useState<Partial<Task>>({ priority: 'backlog' });

  useEffect(() => {
    localStorage.setItem('taskflow_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('taskflow_goals', JSON.stringify(goals));
  }, [goals]);

  const addTask = (task: Omit<Task, 'id' | 'createdAt' | 'completed'>) => {
    const count = tasks.filter(t => t.priority === task.priority && !t.completed).length;
    if (count >= BOX_LIMITS[task.priority as keyof typeof BOX_LIMITS]) {
      alert(`Limit reached for ${task.priority} box!`);
      return;
    }
    const id = crypto.randomUUID();
    setTasks([...tasks, { ...task, id, createdAt: Date.now(), completed: false } as Task]);
    setIsAddingTask(false);
    setNewTask({ priority: 'backlog' });
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 font-sans selection:bg-rose-500/30">
      {/* Header */}
      <header className="px-6 pt-8 pb-4 flex justify-between items-center sticky top-0 bg-[#0a0a0a]/80 backdrop-blur-md z-40">
        <div>
          <p className="text-zinc-500 text-xs font-medium uppercase tracking-widest mb-1">Obsidian Mode</p>
          <h1 className="text-2xl font-bold tracking-tight">TaskFlow AI</h1>
        </div>
        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center shadow-lg shadow-rose-500/20">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
      </header>

      {/* Main Content Area */}
      <main className="pb-32 px-6">
        <AnimatePresence mode="wait">
          {activeTab === 'board' && <BoardView tasks={tasks} onToggle={toggleTask} onDelete={deleteTask} onAdd={() => setIsAddingTask(true)} />}
          {activeTab === 'goals' && <GoalsView goals={goals} />}
          {activeTab === 'chat' && <ChatView tasks={tasks} onAddTask={addTask} />}
          {activeTab === 'analytics' && <AnalyticsView tasks={tasks} />}
        </AnimatePresence>
      </main>

      {/* Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-[#121212]/90 backdrop-blur-xl border-t border-zinc-800/50 px-6 py-4 z-50">
        <div className="max-w-md mx-auto flex justify-between items-center">
          <NavButton active={activeTab === 'board'} onClick={() => setActiveTab('board')} icon={<LayoutDashboard />} label="Board" />
          <NavButton active={activeTab === 'goals'} onClick={() => setActiveTab('goals')} icon={<Target />} label="Goals" />
          <NavButton active={activeTab === 'chat'} onClick={() => setActiveTab('chat')} icon={<MessageSquare />} label="Chat" />
          <NavButton active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} icon={<BarChart3 />} label="Stats" />
        </div>
      </nav>

      {/* Add Task Modal */}
      <AnimatePresence>
        {isAddingTask && (
          <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => setIsAddingTask(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }} 
              animate={{ y: 0 }} 
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-[#18181b] rounded-t-3xl sm:rounded-3xl p-8 border border-zinc-800 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">New Task</h2>
                <button onClick={() => setIsAddingTask(false)} className="p-2 hover:bg-zinc-800 rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="space-y-4">
                <input 
                  autoFocus
                  placeholder="Task Name"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-500/50 transition-all"
                  value={newTask.title || ''}
                  onChange={e => setNewTask({...newTask, title: e.target.value})}
                />
                <textarea 
                  placeholder="The 'Why' / Intention"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-rose-500/50 transition-all h-24 resize-none"
                  value={newTask.why || ''}
                  onChange={e => setNewTask({...newTask, why: e.target.value})}
                />
                
                <div className="grid grid-cols-3 gap-2">
                  {(['critical', 'important', 'backlog'] as Priority[]).map(p => (
                    <button
                      key={p}
                      onClick={() => setNewTask({...newTask, priority: p})}
                      className={cn(
                        "py-2 rounded-lg text-xs font-bold uppercase tracking-wider border transition-all",
                        newTask.priority === p 
                          ? PRIORITY_COLORS[p]
                          : "bg-zinc-900 border-zinc-800 text-zinc-500"
                      )}
                    >
                      {p}
                    </button>
                  ))}
                </div>

                <button 
                  disabled={!newTask.title}
                  onClick={() => addTask(newTask as any)}
                  className="w-full bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white font-bold py-4 rounded-xl shadow-lg shadow-rose-500/20 transition-all mt-4"
                >
                  Create Task
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// --- Sub-Views ---

function BoardView({ tasks, onToggle, onDelete, onAdd }: { 
  tasks: Task[], 
  onToggle: (id: string) => void, 
  onDelete: (id: string) => void,
  onAdd: () => void
}) {
  const sections: { id: Priority, title: string }[] = [
    { id: 'critical', title: 'Critical' },
    { id: 'important', title: 'Important' },
    { id: 'backlog', title: 'Backlog' }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      exit={{ opacity: 0, y: -20 }}
      className="space-y-10"
    >
      {sections.map(section => {
        const sectionTasks = tasks.filter(t => t.priority === section.id && !t.completed);
        const limit = BOX_LIMITS[section.id];
        
        return (
          <section key={section.id} className="space-y-4">
            <div className="flex justify-between items-end px-1">
              <h2 className={cn(
                "text-3xl font-bold tracking-tight",
                section.id === 'critical' ? 'text-rose-500' : 
                section.id === 'important' ? 'text-amber-500' : 'text-emerald-500'
              )}>
                {section.title}
              </h2>
              <span className="text-zinc-500 text-xs font-mono uppercase">
                {sectionTasks.length} / {limit === Infinity ? '∞' : limit} Slots
              </span>
            </div>

            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {sectionTasks.map(task => (
                  // @ts-ignore
                  <TaskCard key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} />
                ))}
              </AnimatePresence>
              
              {sectionTasks.length < limit && (
                <button 
                  onClick={onAdd}
                  className="w-full py-4 border-2 border-dashed border-zinc-800 rounded-2xl text-zinc-600 hover:text-zinc-400 hover:border-zinc-700 transition-all flex items-center justify-center gap-2 group"
                >
                  <Plus className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-bold uppercase tracking-widest">Add {section.title} Priority</span>
                </button>
              )}
            </div>
          </section>
        );
      })}

      {/* Completed Section */}
      {tasks.some(t => t.completed) && (
        <section className="pt-8 border-t border-zinc-800/50">
          <h2 className="text-xl font-bold text-zinc-500 mb-4 px-1">Recently Resolved</h2>
          <div className="space-y-3 opacity-50 grayscale">
            {tasks.filter(t => t.completed).slice(0, 5).map(task => (
              // @ts-ignore
              <TaskCard key={task.id} task={task} onToggle={onToggle} onDelete={onDelete} />
            ))}
          </div>
        </section>
      )}
    </motion.div>
  );
}

function TaskCard({ task, onToggle, onDelete }: { task: Task, onToggle: (id: string) => void, onDelete: (id: string) => void }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95, x: 20 }}
      className={cn(
        "group relative p-5 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-all",
        task.completed && "bg-zinc-900/30"
      )}
    >
      <div className="flex items-start gap-4">
        <button 
          onClick={() => onToggle(task.id)}
          className={cn(
            "mt-1 p-1 rounded-full transition-all",
            task.completed ? "text-emerald-500" : "text-zinc-600 hover:text-zinc-400"
          )}
        >
          {task.completed ? <CheckCircle2 className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
        </button>
        
        <div className="flex-1 min-w-0">
          <h3 className={cn(
            "text-lg font-bold leading-tight truncate",
            task.completed && "line-through text-zinc-600"
          )}>
            {task.title}
          </h3>
          <p className="text-zinc-500 text-sm mt-1 line-clamp-2 italic">
            Why: {task.why}
          </p>
        </div>

        <button 
          onClick={() => onDelete(task.id)}
          className="opacity-0 group-hover:opacity-100 p-2 text-zinc-600 hover:text-rose-500 transition-all"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      
      {/* Accent Bar */}
      <div className={cn(
        "absolute left-0 top-1/4 bottom-1/4 w-1 rounded-r-full",
        task.priority === 'critical' ? 'bg-rose-500' : 
        task.priority === 'important' ? 'bg-amber-500' : 'bg-emerald-500'
      )} />
    </motion.div>
  );
}

function GoalsView({ goals }: { goals: Goal[] }) {
  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className="space-y-8"
    >
      <div className="flex justify-between items-end">
        <h2 className="text-4xl font-bold tracking-tight">Your Goals</h2>
        <span className="text-rose-500 text-xs font-bold uppercase tracking-widest">{goals.length} Active</span>
      </div>

      <div className="p-6 rounded-3xl bg-rose-500/10 border border-rose-500/20 space-y-3">
        <div className="flex items-center gap-2 text-rose-500">
          <AlertCircle className="w-4 h-4" />
          <span className="text-xs font-bold uppercase tracking-widest">AI Strategic Insight</span>
        </div>
        <p className="text-zinc-300 text-sm leading-relaxed">
          You're falling behind on your <span className="text-rose-400 font-bold">Fitness goal</span> — what's getting in the way? Consider scheduling a morning session to reclaim momentum.
        </p>
      </div>

      <div className="space-y-4">
        {goals.map(goal => (
          <div key={goal.id} className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold">{goal.title}</h3>
                <p className="text-zinc-500 text-sm mt-1">{goal.description}</p>
              </div>
              <span className="text-2xl font-mono font-bold" style={{ color: goal.color }}>{goal.progress}%</span>
            </div>
            
            <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${goal.progress}%` }}
                className="h-full rounded-full"
                style={{ backgroundColor: goal.color }}
              />
            </div>
            
            <div className="flex items-center gap-4 text-xs text-zinc-500 font-medium">
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Due {new Date(goal.targetDate).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-1">
                <LayoutDashboard className="w-3 h-3" />
                4 Linked Tasks
              </div>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function ChatView({ tasks, onAddTask }: { tasks: Task[], onAddTask: (task: any) => void }) {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'model', text: "Good morning! What do you want to accomplish today?", timestamp: Date.now() }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      if (input.toLowerCase().includes('remind') || input.toLowerCase().includes('add') || input.toLowerCase().includes('need to')) {
        const parsed = await parseTaskFromNaturalLanguage(input);
        if (parsed) {
          onAddTask(parsed);
          setMessages(prev => [...prev, { 
            id: (Date.now() + 1).toString(), 
            role: 'model', 
            text: `Added to ${parsed.priority} box. Why? (${parsed.why})`, 
            timestamp: Date.now() 
          }]);
          setIsTyping(false);
          return;
        }
      }

      const advice = await getAIAdvice(tasks, input);
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'model', text: advice, timestamp: Date.now() }]);
    } catch (error) {
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "Sorry, I'm having trouble connecting right now.", timestamp: Date.now() }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className="flex flex-col h-[70vh]"
    >
      <div className="flex-1 overflow-y-auto space-y-6 pr-2 scrollbar-hide">
        {messages.map(msg => (
          <div key={msg.id} className={cn(
            "flex flex-col max-w-[85%]",
            msg.role === 'user' ? "ml-auto items-end" : "items-start"
          )}>
            <div className={cn(
              "px-5 py-3 rounded-2xl text-sm leading-relaxed",
              msg.role === 'user' 
                ? "bg-zinc-800 text-zinc-100 rounded-tr-none" 
                : "bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-tl-none"
            )}>
              {msg.text}
            </div>
            <span className="text-[10px] text-zinc-600 mt-1 font-mono">
              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        ))}
        {isTyping && (
          <div className="flex items-center gap-1 px-5 py-3 bg-zinc-900 border border-zinc-800 rounded-2xl rounded-tl-none w-16">
            <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1 }} className="w-1 h-1 bg-zinc-500 rounded-full" />
            <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1 h-1 bg-zinc-500 rounded-full" />
            <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1 h-1 bg-zinc-500 rounded-full" />
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      <div className="mt-6 relative">
        <input 
          placeholder="Message TaskFlow AI..."
          className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-6 py-4 pr-14 focus:outline-none focus:ring-2 focus:ring-rose-500/50 transition-all"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
        />
        <button 
          onClick={handleSend}
          className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-rose-500 text-white rounded-xl shadow-lg shadow-rose-500/20 hover:bg-rose-600 transition-all"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </motion.div>
  );
}

function AnalyticsView({ tasks }: { tasks: Task[] }) {
  const weeklyData = [
    { day: 'Mon', completed: 4 },
    { day: 'Tue', completed: 6 },
    { day: 'Wed', completed: 8 },
    { day: 'Thu', completed: 5 },
    { day: 'Fri', completed: 9 },
    { day: 'Sat', completed: 3 },
    { day: 'Sun', completed: 2 },
  ];

  const boxData = [
    { name: 'Critical', value: tasks.filter(t => t.priority === 'critical' && t.completed).length, total: tasks.filter(t => t.priority === 'critical').length, color: '#f43f5e' },
    { name: 'Important', value: tasks.filter(t => t.priority === 'important' && t.completed).length, total: tasks.filter(t => t.priority === 'important').length, color: '#f59e0b' },
    { name: 'Backlog', value: tasks.filter(t => t.priority === 'backlog' && t.completed).length, total: tasks.filter(t => t.priority === 'backlog').length, color: '#10b981' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className="space-y-8"
    >
      <div className="flex justify-between items-start">
        <div>
          <p className="text-rose-500 text-xs font-bold uppercase tracking-widest mb-1">Performance Pulse</p>
          <h2 className="text-4xl font-bold tracking-tight">Analytics</h2>
        </div>
        <div className="px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center gap-2">
          <span className="text-amber-500">🔥</span>
          <span className="text-sm font-bold">7 Day Streak</span>
        </div>
      </div>

      {/* Weekly Chart */}
      <div className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 space-y-6">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold">Weekly Completion</h3>
          <div className="text-right">
            <span className="text-2xl font-mono font-bold text-emerald-500">84%</span>
            <p className="text-[10px] text-zinc-500 uppercase font-bold">Avg Completion</p>
          </div>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
              <XAxis dataKey="day" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
              <YAxis hide />
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '12px' }}
                itemStyle={{ color: '#f43f5e' }}
              />
              <Line type="monotone" dataKey="completed" stroke="#f43f5e" strokeWidth={3} dot={{ fill: '#f43f5e', strokeWidth: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Box Breakdown */}
      <div className="grid grid-cols-1 gap-4">
        {boxData.map(box => (
          <div key={box.name} className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{box.name}</p>
              <h4 className="text-3xl font-mono font-bold">{box.total > 0 ? Math.round((box.value / box.total) * 100) : 0}%</h4>
              <p className="text-xs text-zinc-600">{box.value}/{box.total} Tasks Resolved</p>
            </div>
            <div className="w-24 h-2 bg-zinc-800 rounded-full overflow-hidden rotate-[-90deg] origin-right">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${box.total > 0 ? (box.value / box.total) * 100 : 0}%` }}
                className="h-full"
                style={{ backgroundColor: box.color }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* AI Insight Card */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-rose-500 to-rose-600 text-white space-y-4 relative overflow-hidden">
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 opacity-80">
            <Sparkles className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-widest">AI Insight</span>
          </div>
          <p className="text-lg font-medium leading-snug">
            You're most productive on <span className="underline decoration-2 underline-offset-4">Wednesdays</span> between <span className="underline decoration-2 underline-offset-4">9 AM and 11 AM</span>.
          </p>
        </div>
        <div className="absolute right-[-20px] top-[-20px] opacity-10">
          <BarChart3 className="w-40 h-40" />
        </div>
      </div>
    </motion.div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-1 transition-all",
        active ? "text-rose-500 scale-110" : "text-zinc-600 hover:text-zinc-400"
      )}
    >
      <div className={cn(
        "p-2 rounded-xl transition-all",
        active && "bg-rose-500/10"
      )}>
        {React.cloneElement(icon as React.ReactElement, { className: "w-6 h-6" })}
      </div>
      <span className="text-[10px] font-bold uppercase tracking-widest">{label}</span>
    </button>
  );
}
